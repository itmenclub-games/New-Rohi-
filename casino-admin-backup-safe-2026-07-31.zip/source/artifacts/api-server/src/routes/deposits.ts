import { Router } from "express";
import { conversationsTable, db, depositsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { getTelegramFileUrl, sendTelegramMessage } from "../lib/telegram";
import { saveConversationMessage } from "../lib/conversation";

const router = Router();

async function notifyDepositCustomer(
  conversationId: number,
  text: string,
): Promise<void> {
  const [conversation] = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, conversationId));
  if (!conversation) return;

  await sendTelegramMessage(conversation.customerTelegramId, text);
  await saveConversationMessage(conversation.id, text, "staff", "Staff");
}


// Streams payment screenshots from Telegram without exposing the bot token to browsers.
// New records contain Telegram file IDs; the fallback supports pre-existing Telegram URLs.
router.get("/deposits/:id/screenshot", async (req, res): Promise<void> => {
  try {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    if (!Number.isInteger(id)) { res.status(400).json({ error: "Invalid deposit ID" }); return; }

    const [deposit] = await db.select().from(depositsTable).where(eq(depositsTable.id, id));
    if (!deposit?.screenshotUrl) { res.status(404).json({ error: "Screenshot not found" }); return; }

    const storedValue = deposit.screenshotUrl;
    const url = storedValue.startsWith("https://api.telegram.org/file/bot")
      ? storedValue
      : await getTelegramFileUrl(storedValue);
    if (!url) { res.status(404).json({ error: "Screenshot is no longer available from Telegram" }); return; }

    const telegramResponse = await fetch(url);
    if (!telegramResponse.ok) {
      req.log.warn({ depositId: id, status: telegramResponse.status }, "Telegram screenshot download failed");
      res.status(502).json({ error: "Could not retrieve screenshot from Telegram" });
      return;
    }

    const contentType = telegramResponse.headers.get("content-type") || "image/jpeg";
    if (!contentType.startsWith("image/")) {
      res.status(415).json({ error: "Telegram file is not an image" });
      return;
    }

    res.setHeader("Content-Type", contentType);
    res.setHeader("Cache-Control", "private, max-age=300");
    res.send(Buffer.from(await telegramResponse.arrayBuffer()));
  } catch (err) {
    req.log.error({ err }, "Failed to load Telegram screenshot");
    res.status(500).json({ error: "Failed to load screenshot" });
  }
});

router.get("/deposits", async (req, res): Promise<void> => {
  try {
    const { status } = req.query as Record<string, string>;
    const results = status
      ? await db.select().from(depositsTable).where(eq(depositsTable.status, status)).orderBy(desc(depositsTable.createdAt))
      : await db.select().from(depositsTable).orderBy(desc(depositsTable.createdAt));
    res.json(results.map(r => ({ ...r, amount: r.amount ? Number(r.amount) : null })));
  } catch (err) {
    req.log.error({ err }, "Failed to list deposits");
    res.status(500).json({ error: "Failed to list deposits" });
  }
});

router.patch("/deposits/:id/approve", async (req, res): Promise<void> => {
  try {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    const [updated] = await db.update(depositsTable).set({ status: "approved", updatedAt: new Date() }).where(eq(depositsTable.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "Not found" }); return; }
    await notifyDepositCustomer(
      updated.conversationId,
      "Your deposit request has been approved. Staff will let you know when it is completed.",
    );
    res.json({ ...updated, amount: updated.amount ? Number(updated.amount) : null });
  } catch (err) {
    req.log.error({ err }, "Failed to approve deposit");
    res.status(500).json({ error: "Failed to approve deposit" });
  }
});

router.patch("/deposits/:id/reject", async (req, res): Promise<void> => {
  try {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    const { reason } = req.body;
    const [updated] = await db.update(depositsTable).set({ status: "rejected", rejectionReason: reason || null, updatedAt: new Date() }).where(eq(depositsTable.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "Not found" }); return; }
    await notifyDepositCustomer(
      updated.conversationId,
      `Your deposit request was not approved${reason ? `: ${reason}` : "."}`,
    );
    res.json({ ...updated, amount: updated.amount ? Number(updated.amount) : null });
  } catch (err) {
    req.log.error({ err }, "Failed to reject deposit");
    res.status(500).json({ error: "Failed to reject deposit" });
  }
});

router.patch("/deposits/:id/complete", async (req, res): Promise<void> => {
  try {
    const id = parseInt(Array.isArray(req.params.id) ? req.params.id[0] : req.params.id, 10);
    const [updated] = await db.update(depositsTable).set({ status: "completed", updatedAt: new Date() }).where(eq(depositsTable.id, id)).returning();
    if (!updated) { res.status(404).json({ error: "Not found" }); return; }
    await notifyDepositCustomer(
      updated.conversationId,
      "Your deposit has been completed. Thank you!",
    );
    res.json({ ...updated, amount: updated.amount ? Number(updated.amount) : null });
  } catch (err) {
    req.log.error({ err }, "Failed to complete deposit");
    res.status(500).json({ error: "Failed to complete deposit" });
  }
});

export default router;
