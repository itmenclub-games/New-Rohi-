import app from "./app";
import { logger } from "./lib/logger";
import { setTelegramWebhook } from "./lib/telegram";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Auto-register Telegram webhook on startup
  const domain = process.env.REPLIT_DEV_DOMAIN;
  if (domain) {
    const webhookUrl = `https://${domain}/api/bot/webhook`;
    await setTelegramWebhook(webhookUrl);
  } else {
    logger.warn("REPLIT_DEV_DOMAIN not set — skipping Telegram webhook registration");
  }
});
