# Redacted database export

The CSV export intentionally omits sensitive or customer-content columns:

- `settings.groq_api_key`
- `game_account_requests.credentials_username`
- `game_account_requests.credentials_password`
- `payment_tags.account_details`
- Customer names and Telegram IDs from request/conversation tables
- Conversation and message text
- Payment details, deposit details, screenshots, and media URLs
- Rejection messages and other free-form customer/staff content

The schema-only dump still contains the table definitions for these columns so the application remains structurally restorable, but it contains no values for them.
