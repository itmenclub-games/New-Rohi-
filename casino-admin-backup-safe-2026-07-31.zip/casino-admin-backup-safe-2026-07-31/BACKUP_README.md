# Casino Admin Dashboard + Telegram Bot — Safe Backup

Created: 2026-07-31 UTC

This archive contains the project source, tracked configuration, generated API clients, lockfiles, assets, database schema, and a redacted database export.

## Intentionally excluded

Raw credentials and sensitive values are not included:

- Replit Secrets: `TELEGRAM_BOT_TOKEN`, `GROQ_API_KEY`, and `SESSION_SECRET`
- Managed PostgreSQL connection credentials: `DATABASE_URL`, `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, and `PGDATABASE`
- Groq key stored in the database settings table
- Game-account usernames and passwords
- Payment tag account details
- Customer names and Telegram IDs
- Conversation text, rejection/details text, screenshots, media URLs, and payment details

These values must remain in Replit Secrets / the database environment and should not be emailed, committed, or placed in a normal ZIP file.

## Restore checklist

1. Extract the `source/` directory into a new workspace.
2. Install the pinned dependencies with `pnpm install`.
3. Provision or attach PostgreSQL so `DATABASE_URL` is available.
4. Apply the schema from `database/schema.sql` or use the platform's publish-time database schema flow.
5. Set the application secrets through the Replit Secrets pane:
   - `TELEGRAM_BOT_TOKEN`
   - `GROQ_API_KEY`
   - `SESSION_SECRET`
6. Restore any intentionally excluded operational data through a secure, separate process.
7. Start the API and dashboard workflows from the commands in `source/.replit` and the artifact manifests.

## Database backup contents

- `database/schema.sql` — schema-only PostgreSQL dump; no row data or credentials.
- `database/data/*.csv` — sanitized operational/configuration exports. Sensitive columns are omitted rather than masked in place.
- `database/EXCLUDED_DATA.md` — exact categories excluded from the redacted export.

The redacted CSV files are not a full production-data backup. They are included to preserve non-sensitive configuration and request/status context without exporting credentials or customer content.
